﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Constants
    {
        public const int DAYS = 5;
        public const int HOURS_PER_DAY = 8;
    }
}
