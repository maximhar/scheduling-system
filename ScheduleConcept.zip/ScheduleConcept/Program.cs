﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Program
    {
        static void Main(string[] args)
        {
            Configuration conf = Configuration.GetInstance();
            //conf.StudentGroups.Add(0, new StudentGroup(0, "A", 28));
            //conf.Courses.Add(0, new Course(0, "Literature"));
            //conf.Courses.Add(1, new Course(1, "Maths"));
            //conf.Courses.Add(2, new Course(2, "TP"));
            //conf.Courses.Add(3, new Course(3, "OOP"));
            //conf.Rooms.Add(0, new Room("21", false, 30));
            //conf.Rooms.Add(1, new Room("42", false, 30));
            //conf.Rooms.Add(2, new Room("32", true, 30));
            //Professor p1 = new Professor(0, "Slanina Kitova");
            //Professor p2 = new Professor(1, "Abramowitch");
            //Professor p3 = new Professor(2, "Kiril Mitov");
            //Professor p4 = new Professor(3, "Chorbadjiev");
            //var c1 = new CourseClass(p1, conf.Courses[0], new List<StudentGroup> { conf.StudentGroups[0] }, false, 2);
            //var c2 = new CourseClass(p2, conf.Courses[1], new List<StudentGroup> { conf.StudentGroups[0] }, false, 2);
            //var c3 = new CourseClass(p3, conf.Courses[2], new List<StudentGroup> { conf.StudentGroups[0] }, true, 2);
            //var c4 = new CourseClass(p4, conf.Courses[3], new List<StudentGroup> { conf.StudentGroups[0] }, true, 2);
            //p1.AddCourseClass(c1);
            //p2.AddCourseClass(c2);
            //p3.AddCourseClass(c3);
            //p4.AddCourseClass(c4);
            
            //conf.CourseClasses.Add(c1);
            //conf.CourseClasses.Add(c2);
            //conf.CourseClasses.Add(c3);
            //conf.CourseClasses.Add(c4);
            //conf.Professors.Add(0, p1);
            //conf.Professors.Add(1, p2);
            //conf.Professors.Add(2, p3);
            //conf.Professors.Add(3, p4);
            string path = "C:/info.xml";
            Console.WriteLine("Reading from: {0}", path);
            conf.ReadFromXML(path);
            Algorithm a = Algorithm.GetInstance();
            a.EvolutionStateChanged += new EventHandler(a_EvolutionStateChanged);
            a.StateChanged += new EventHandler(a_StateChanged);
            a.NewBestChromosome += new EventHandler(a_NewBestChromosome);
            a.Start();
            Console.ReadLine();
        }

        static void a_NewBestChromosome(object sender, EventArgs e)
        {
            Console.WriteLine("New best chromosome found: fitness {0}", (sender as Algorithm).GetBestChromosome().Fitness);
        }

        static void a_StateChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Algorithm state: {0}", (sender as Algorithm).State);
            if ((sender as Algorithm).State == AlgorithmState.CRITERIA_STOPPED)
            {
                Schedule s = (sender as Algorithm).GetBestChromosome();
                DisplaySchedule(s);
            }
        }
        static void DisplaySchedule(Schedule s)
        {
            int daySize = Constants.HOURS_PER_DAY * Configuration.GetInstance().Rooms.Count;
            var classes = from v in s.Classes
                          let day = v.Value / daySize
                          let time = v.Value % daySize
                          let room = time / Constants.HOURS_PER_DAY
                          let finaltime = time % Constants.HOURS_PER_DAY
                          select new { Day = day, Professor = v.Key.ClassProfessor, Time = finaltime, Course = v.Key.ClassCourse, Duration = v.Key.Length, Room = Configuration.GetInstance().GetRoomByID(room), Group = v.Key.StudentGroups[0] };
            var sortedclasses = from c in classes
                                orderby c.Time ascending
                                orderby c.Day ascending
                                group c by c.Day;
            Console.WriteLine("     {0, -4} {1, -7} {2, -8} {3, -15} {5, -4} {4,-4}", "Time", "Group", "Course", "Professor", "Duration", "Room");
            foreach (var day in sortedclasses)
            {
                Console.WriteLine("Day {0}:", day.Key);
                foreach(var c in day)
                {
                    string line = string.Format("{0, -4} {1, -7} {2, -8} {3, -15} {5, -4} {4,-4}", c.Time, c.Group.Name, c.Course.Name, c.Professor.Name, c.Duration, c.Room.Name);
                    Console.WriteLine("     {0}", line);
                }
            }
        }
        static void a_EvolutionStateChanged(object sender, EventArgs e)
        {
            //Console.WriteLine((sender as Algorithm).GetBestChromosome().Fitness);
        }
    }
}
