﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Configuration
    {
        static Configuration _instance;
        static public Configuration GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Configuration();
            }
            return _instance;
        }
        public Configuration()
        {
            Empty = true;
            Professors = new Dictionary<int, Professor>();
            StudentGroups = new Dictionary<int, StudentGroup>();
            Courses = new Dictionary<int, Course>();
            Rooms = new Dictionary<int, Room>();
            CourseClasses = new List<CourseClass>();
        }
        public Dictionary<int, Professor> Professors { get; set; }
        public Dictionary<int, StudentGroup> StudentGroups { get; set; }
        public Dictionary<int, Course> Courses { get; set; }
        public Dictionary<int, Room> Rooms { get; set; }
        public List<CourseClass> CourseClasses { get; set; }
        public bool Empty { get; set; }
        public Course GetCourseByID(int id)
        {
            Course result = null;
            Courses.TryGetValue(id, out result);
            return result;
        }
        public Room GetRoomByID(int id)
        {
            Room result = null;
            Rooms.TryGetValue(id, out result);
            return result;
        }
        public StudentGroup GetStudentGroupByID(int id)
        {
            StudentGroup result = null;
            StudentGroups.TryGetValue(id, out result);
            return result;
        }
        public Professor GetProfessorByID(int id)
        {
            Professor result = null;
            Professors.TryGetValue(id, out result);
            return result;
        }
    }
}
