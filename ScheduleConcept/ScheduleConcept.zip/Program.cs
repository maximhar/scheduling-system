﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Program
    {
        static void Main(string[] args)
        {
            Configuration conf = Configuration.GetInstance();
            conf.StudentGroups.Add(0, new StudentGroup(0, "A", 28));
            conf.Courses.Add(0, new Course(0, "Literature"));
            conf.Courses.Add(1, new Course(1, "Maths"));
            conf.Rooms.Add(0, new Room("21", false, 30));
            conf.Rooms.Add(1, new Room("42", false, 30));
            Professor p1 = new Professor(0, "Slanina Mitova");
            p1.Classes.Add(new CourseClass(p1, conf.Courses[0], new List<StudentGroup>{conf.StudentGroups[0]}, false, 2));
            Professor p2 = new Professor(0, "Abramowitch");
            p2.Classes.Add(new CourseClass(p2, conf.Courses[1], new List<StudentGroup> { conf.StudentGroups[0] }, false, 2));
            conf.Professors.Add(0, p1);
            conf.Professors.Add(1, p2);
            Algorithm a = Algorithm.GetInstance();
            a.EvolutionStateChanged += new EventHandler(a_EvolutionStateChanged);
            a.StateChanged += new EventHandler(a_StateChanged);
            a.Start();
            Console.ReadLine();
        }

        static void a_StateChanged(object sender, EventArgs e)
        {
            Console.WriteLine("State: {0}", (sender as Algorithm).State);
        }

        static void a_EvolutionStateChanged(object sender, EventArgs e)
        {
            Console.WriteLine((sender as Algorithm).GetBestChromosome().Fitness);
        }
    }
}
