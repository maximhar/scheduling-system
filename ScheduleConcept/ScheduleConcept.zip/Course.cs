﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Course
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public Course(int id, string name)
        {
        }
    }
}
