﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Program
    {
        static void Main(string[] args)
        {
            Configuration conf = Configuration.GetInstance();
            conf.StudentGroups.Add(0, new StudentGroup(0, "A", 28));
            conf.Courses.Add(0, new Course(0, "Literature"));
            conf.Courses.Add(1, new Course(1, "Maths"));
            conf.Courses.Add(2, new Course(2, "TP"));
            conf.Rooms.Add(0, new Room("21", false, 30));
            conf.Rooms.Add(1, new Room("42", false, 30));
            conf.Rooms.Add(2, new Room("32", true, 30));
            Professor p1 = new Professor(0, "Slanina Mitova");
            Professor p2 = new Professor(1, "Abramowitch");
            Professor p3 = new Professor(2, "Kiril Mitov");
            var c1 = new CourseClass(p1, conf.Courses[0], new List<StudentGroup> { conf.StudentGroups[0] }, false, 2);
            var c2 = new CourseClass(p2, conf.Courses[1], new List<StudentGroup> { conf.StudentGroups[0] }, false, 2);
            var c3 = new CourseClass(p3, conf.Courses[2], new List<StudentGroup> { conf.StudentGroups[0] }, true, 2);
            p1.Classes.Add(c1);
            p2.Classes.Add(c2);
            p3.AddCourseClass(c3);
            conf.CourseClasses.Add(c1);
            conf.CourseClasses.Add(c2);
            conf.CourseClasses.Add(c3);
            conf.Professors.Add(0, p1);
            conf.Professors.Add(1, p2);
            conf.Professors.Add(2, p3);
            Algorithm a = Algorithm.GetInstance();
            a.EvolutionStateChanged += new EventHandler(a_EvolutionStateChanged);
            a.StateChanged += new EventHandler(a_StateChanged);
            a.NewBestChromosome += new EventHandler(a_NewBestChromosome);
            a.Start();
            Console.ReadLine();
        }

        static void a_NewBestChromosome(object sender, EventArgs e)
        {
            //Console.WriteLine("New best chromosome {0}", (sender as Algorithm).GetBestChromosome().Fitness);
        }

        static void a_StateChanged(object sender, EventArgs e)
        {
            Console.WriteLine("State: {0}", (sender as Algorithm).State);
            if ((sender as Algorithm).State == AlgorithmState.CRITERIA_STOPPED)
            {
                Schedule s = (sender as Algorithm).GetBestChromosome();
                Console.WriteLine(s.Fitness);
                foreach (var v in s.Classes)
                {
                    int daySize = Constants.HOURS_PER_DAY * Configuration.GetInstance().Rooms.Count;
                    int time = v.Value / Constants.HOURS_PER_DAY;
                    int room = time / Constants.HOURS_PER_DAY;
                    Console.WriteLine("{0} : {1}", Configuration.GetInstance().GetRoomByID(room).Name, v.Key);
                }
            }
        }

        static void a_EvolutionStateChanged(object sender, EventArgs e)
        {
            //Console.WriteLine((sender as Algorithm).GetBestChromosome().Fitness);
        }
    }
}
