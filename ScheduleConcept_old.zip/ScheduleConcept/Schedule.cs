﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class Schedule
    {
        Random _random = new Random(DateTime.Now.Millisecond);
        List<CourseClass>[] _timeslots;
        public List<CourseClass>[] Timeslots
        {
            get
            {
                return _timeslots;
            }
        }
        public Dictionary<CourseClass, int> Classes
        {
            get
            {
                return _classes;
            }
        }
        Dictionary<CourseClass, int> _classes;
        float _fitness;
        public float Fitness
        {
            get
            {
                return _fitness;
            }
        }
        bool[] _criteria;
        int _numberOfCrossoverPoints;
        int _mutationSize;
        int _crossoverProbability;
        int _mutationProbability;



        void InitializeListCapacities()
        {
            _timeslots = new List<CourseClass>[Constants.DAYS * Constants.HOURS_PER_DAY * Configuration.GetInstance().Rooms.Count + 1];
            for (int i = 0; i < _timeslots.Length; i++)
            {
                _timeslots[i] = new List<CourseClass>();
            }
            _classes = new Dictionary<CourseClass, int>();
            _criteria = new bool[Configuration.GetInstance().Courses.Count * 5];
        }
        public Schedule(int numberOfCrossoverPoints, int mutationSize, int crossoverProbability, int mutationProbability)
        {
            _numberOfCrossoverPoints = numberOfCrossoverPoints;
            _mutationSize = mutationSize;
            _crossoverProbability = crossoverProbability;
            _mutationProbability = mutationProbability;

            InitializeListCapacities();
        }
        public Schedule(Schedule c, bool shallow)
        {
            if (!shallow)
            {
                _timeslots = c._timeslots;
                _classes = c._classes;
                _criteria = c._criteria;
                _fitness = c._fitness;
            }
            else
            {
                InitializeListCapacities();
            }
            _numberOfCrossoverPoints = c._numberOfCrossoverPoints;
            _mutationSize = c._mutationSize;
            _crossoverProbability = c._crossoverProbability;
            _mutationProbability = c._mutationProbability;
        }

        public Schedule()
        {
            _timeslots = new List<CourseClass>[0];
            _classes = new Dictionary<CourseClass, int>();
            _criteria = new bool[0];
        }
        public Schedule Clone(bool shallow)
        {
            return new Schedule(this, shallow);
        }
        public Schedule CreateNewFromPrototype() 
        {
            int size = _timeslots.Length;
            Schedule newChromosome = new Schedule(this, true);

            List<CourseClass> classes = Configuration.GetInstance().CourseClasses;
            int roomCount = Configuration.GetInstance().Rooms.Count;
            foreach (CourseClass c in classes)
            {
                int duration = c.Length;
                int day = _random.Next(Constants.DAYS);
                int room = _random.Next(roomCount);
                int time = _random.Next(Constants.HOURS_PER_DAY - 1 + duration);
                int pos = day * roomCount * Constants.HOURS_PER_DAY + room * Constants.DAYS + time;
                for(int i = duration-1;i>=0;i--)
                {
                    newChromosome._timeslots[pos+i].Add(c);
                }
                newChromosome._classes.Add(c, pos);
            }
            newChromosome.CalculateFitness();
            return newChromosome;
        }
        public Schedule CrossOver(Schedule parent2) 
        {
            if (_random.Next(100) > _crossoverProbability)
                return new Schedule(this, false);

            Schedule s = new Schedule(this, true);
            int numberOfClasses = _classes.Count;
            bool[] cp = new bool[numberOfClasses];
            for (int i = _numberOfCrossoverPoints; i > 0; i--)
            {
                while (true)
                {
                    int p = _random.Next(numberOfClasses);
                    if (!cp[p])
                    {
                        cp[p] = true;
                        break;
                    }
                }
            }
            var classes1 = _classes.GetEnumerator();
            var classes2 = parent2._classes.GetEnumerator();

            bool first = _random.Next(0,2)==0;
            for (int i = 0; i < numberOfClasses; i++)
            {
                classes1.MoveNext();
                classes2.MoveNext();
                if (first)
                {
                    s._classes.Add(classes1.Current.Key, classes1.Current.Value);
                    for (int j = classes1.Current.Key.Length - 1; j >= 0; j--)
                    {
                        s._timeslots[classes1.Current.Value + j].Add(classes1.Current.Key);
                    }
                }
                else
                {
                    s._classes.Add(classes2.Current.Key, classes2.Current.Value);
                    for (int j = classes2.Current.Key.Length - 1; j >= 0; j--)
                    {
                        s._timeslots[classes2.Current.Value + j].Add(classes2.Current.Key);
                    }
                }
                if (cp[i]) first = !first;
                
            }
            s.CalculateFitness();
            return s;
        }
        public void Mutation() 
        {
            if (_random.Next(100) > _mutationProbability)
                return;
            int numberOfClasses = _classes.Count;
            int size = _timeslots.Length;

            for (int i = _mutationSize; i > 0; i--)
            {
                int mpos = _random.Next(numberOfClasses);
                int pos1 = 0;
                var enumerator = _classes.GetEnumerator();
                enumerator.MoveNext();
                for (; mpos > 0; enumerator.MoveNext(), mpos--) ;

                pos1 = enumerator.Current.Value;
                CourseClass cc1 = enumerator.Current.Key;
                int roomCount = Configuration.GetInstance().Rooms.Count;
                int duration = cc1.Length;
                int day = _random.Next(Constants.DAYS);
                int room = _random.Next(roomCount);
                int time = _random.Next(Constants.HOURS_PER_DAY - 1 + duration);
                int pos2 = day * roomCount * Constants.HOURS_PER_DAY + room * Constants.DAYS + time;

                for (int j = duration - 1; j >= 0; j--)
                {
                    List<CourseClass> cl = _timeslots[pos1 + j];
                    for (int k = cl.Count-1; k >= 0; k--)
                    {
                        if (cl[k] == cc1)
                        {
                            cl.RemoveAt(k);
                            break;
                        }
                    }
                }
                _timeslots[pos2 + i].Add(cc1);
                _classes[cc1] = pos2;
            }
            CalculateFitness();
        }
        public void CalculateFitness()
        {
            int score = 0;
            int numberOfRooms = Configuration.GetInstance().Rooms.Count;
            int daySize = numberOfRooms * Constants.HOURS_PER_DAY;

            int ci = 0;

            foreach (var item in _classes)
            {
                int p = item.Value;
                int day = p / daySize;
                int time = p % daySize;
                int room = time / Constants.HOURS_PER_DAY;
                time = time % Constants.HOURS_PER_DAY;
                int duration = item.Key.Length;
                //check for room overlap
                bool roomOverlap = DoesRoomOverlap(p, duration);
                if (!roomOverlap) score++;
                _criteria[ci + 0] = !roomOverlap;
                //check for necessary room capacity
                CourseClass cc = item.Key;
                Room r = Configuration.GetInstance().GetRoomByID(room);
                _criteria[ci + 1] = r.Capacity >= cc.StudentCount;
                if (_criteria[ci + 1]) score++;
                //check for computers
                _criteria[ci + 2] = !cc.RequiresLab || (cc.RequiresLab && r.IsLab);
                if (_criteria[ci + 2]) score++;
                //check for overlapping of classes for professors and student groups
                bool po = false, go = false;
                for (int i = numberOfRooms, t = day * daySize + time; i > 0; i--, t += Constants.HOURS_PER_DAY)
                {
                    for (int j = duration - 1; j >= 0; j--)
                    {
                        List<CourseClass> cl = _timeslots[t + j];
                        foreach (var c in cl)
                        {
                            if (cc != c)
                            {
                                if (!po && cc.ProfessorOverlaps(c)) po = true;
                                if (!go && cc.GroupsOverlap(c)) go = true;
                                if (po && go) goto total_overlap;
                            }
                        }
                    }
                }
total_overlap:
                if (!po) score++;
                _criteria[ci + 3] = !po;
                if (!go) score++;
                _criteria[ci + 4] = !go;
            }
            _fitness = (float)score / (Configuration.GetInstance().CourseClasses.Count * Constants.DAYS);
        }
        private bool DoesRoomOverlap(int p, int duration)
        {
            bool roomOverlap = false;
            for (int i = duration - 1; i >= 0; i--)
            {
                if (_timeslots[p + i].Count > 1)
                {
                    roomOverlap = true;
                    break;
                }
            }
            return roomOverlap;
        }
		
    }
}
