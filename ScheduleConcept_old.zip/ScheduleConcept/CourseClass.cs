﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleConcept
{
    class CourseClass
    {
        public Course ClassCourse { get; set; }
        public Professor ClassProfessor { get; set; }
        public List<StudentGroup> StudentGroups { get; set; }
        public int Length { get; set; }
        public bool RequiresLab { get; set; }
        public int StudentCount
        {
            get
            {
                return StudentGroups.Sum(group => group.Size);
            }
        }
        public CourseClass(Professor professor, Course course, List<StudentGroup> groups, bool requiresLab, int duration)
        {
            ClassProfessor = professor;
            ClassCourse = course;
            StudentGroups = groups;
            RequiresLab = requiresLab;
            Length = duration;
        }
        public bool GroupsOverlap(CourseClass c) 
        {
            return c.StudentGroups.Any(group =>
                {
                    return StudentGroups.Any(innerGroup => innerGroup == group);
                });
        }
        public bool ProfessorOverlaps(CourseClass c ) { return ClassProfessor == c.ClassProfessor; }
        public override string ToString()
        {
            return string.Format("Course {0}, Professor {1}, Length {2}", ClassCourse.Name, ClassProfessor.Name, Length);
        }
    }
}
